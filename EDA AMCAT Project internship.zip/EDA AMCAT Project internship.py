#!/usr/bin/env python
# coding: utf-8

# ### Importing Libraies

# In[1]:


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime


# In[2]:


import warnings
warnings.filterwarnings('ignore')


# ### Loading dataset

# In[3]:


df = pd.read_excel(r"C:\Users\Admin\Downloads\data (1).xlsx")


# In[4]:


df.head()


# In[89]:


df.describe()


# In[5]:


df.dtypes


# In[6]:


df.drop('Unnamed: 0',axis=1,inplace=True)


# In[7]:


df[['DOJ','DOB']] = df[['DOJ','DOB']].astype('object')
df['Salary'] = df['Salary'].astype('float64')


# In[8]:


df.columns


# In[9]:


df['DOJ'] = pd.to_datetime(df['DOJ'])
df['DOB'] = pd.to_datetime(df['DOB'])
df['Age'] = 2024 - df['DOB'].dt.year 


# In[10]:


today_date = datetime.today().strftime('%Y-%m-%d')
df['DOL'] = df['DOL'].replace('present', today_date)


# In[11]:


df['DOL'].unique()


# In[12]:


df['Designation'].nunique()


# In[13]:


df['DOL'] = pd.to_datetime(df['DOL'], errors='coerce')


# In[14]:


df['WorkYear'] = df['DOL'].dt.year - df['DOJ'].dt.year


# In[15]:


df.head()


# In[16]:


df['Specialization'].unique()


# ### Short Type Corrections

# In[17]:


def clean_row_board(row): 
    if 'cbse' in row:
        return 'CBSE'
    elif 'icse' in row:
        return 'ICSE'
    elif 'poly' in row:
        return 'Polytechnic'
    else:
        return 'State Board'
    return row
    


# In[18]:


def clean_row_specialisation(row): 
    if 'computer' in row:
        return 'CSE'
    elif 'communication' in row:
        return 'ECE'
    elif 'information' in row:
        return 'IT'
    elif 'electrical' in row:
        return 'EEE'
    elif 'electro' in row:
        return 'EEE'
    elif 'telecomm' in row:
        return 'EEE'
    elif 'power' in row:
        return 'EEE'
    elif 'embedded' in row:
        return 'EEE'
    elif 'combus' in row:
        return 'Mechanical Engg'
    elif 'polymer' in row:
        return 'Chemical Engg'
    elif 'chem' in row:
        return 'Chemical Engg'
    elif 'civil' in row:
        return 'Civil Engg'
    elif 'metallurgical' in row:
        return 'Metallurgical Engg'
    elif 'instrument' in row:
        return 'Instrumentation Engg'
    elif 'mech' in row:
        return 'Mechanical Engg'
    elif 'industrial' in row:
        return 'Production Engg'
    elif 'bio' in row:
        return 'Biomedical Engineering'
    elif 'auto' in row:
        return 'Automobiles'
    elif 'aero' in row:
        return 'Aeronautical Engg'
    elif 'ceramic' in row:
        return 'Civil Engg'
    return row


# In[19]:


df['Specialization'] = df['Specialization'].apply(clean_row_specialisation)


# In[20]:


df['Specialization'].nunique()


# In[21]:


df.head()


# In[22]:


amcat_marks = df[['English','Logical','Quant','ComputerProgramming','ElectronicsAndSemicon',
                   'ComputerScience','MechanicalEngg','ElectricalEngg','TelecomEngg','CivilEngg']]


# In[23]:


amcat_marks


# In[24]:


subject_counts = pd.DataFrame(index=amcat_marks.columns, columns=['Appeared', 'Non-Appeared'])

# Counting appeared and non-appeared for each subject
subject_counts['Appeared'] = (amcat_marks != -1).sum()
subject_counts['Non-Appeared'] = (amcat_marks == -1).sum()
subject_counts['Percentage_appeared'] = round((subject_counts['Appeared']/3964)*100,2)
subject_counts.head(10)


# In[25]:


plt.barh(width=subject_counts['Percentage_appeared'],y=subject_counts.index)
plt.xlabel('Percentage Appeared')
plt.ylabel('Subjects')
plt.title('Percentage of Students Appeared in Each Subject')


# ### Univariate Analysis

# In[26]:


# complete statistical analysis of discrete data ( cate & num)


# In[27]:


def discrete_non_viz_analysis(data):
    series = pd.Series(data)
    print(series.agg(['count', 'nunique', 'unique']))
    print('Value Counts: \n', series.value_counts())
    print()


# In[28]:


# complete statistical analysis of continous numerical data


# In[29]:


def continuous_non_viz_analysis(data):
    series = pd.Series(data)
    print(series.agg(['count', 'min', 'max', 'mean', 'median', 'var', 'std', 'skew', 'kurt']).round(2))
    print()


# In[30]:


# this funition performs a complete analysis of discrete data ( cate & num)


# In[31]:


def discrete_viz_analysis(data):
    fig, ax = plt.subplots(figsize=(5, 3), constrained_layout=True)
    fig.suptitle("Discrete Distribution Plot")
    
    ax.set_title("Count Plot")
    sns.countplot(x=data, ax=ax)
    
    plt.xticks(rotation=45)
    plt.show()


# In[32]:


# this function performs a complete analysis of continous numerical data


# In[33]:


def continuous_viz_analysis(data):
    fig, axes = plt.subplots(1, 3, figsize=(8, 3), constrained_layout=True)
    fig.suptitle("Continuous Distribution Plot")
    
    axes[0].set_title("Histogram Plot")
    sns.histplot(data, ax=axes[0])
    
    axes[1].set_title("KDE Plot")
    sns.kdeplot(data, fill=True, ax=axes[1])

    axes[2].set_title("Box Plot")
    sns.boxplot(data, ax=axes[2])

    plt.show()


# In[34]:


# IQR Technic


# In[35]:


def iqr_technique(DFcolumn):
    Q1 = np.percentile(DFcolumn, 25)
    Q3 = np.percentile(DFcolumn, 75)
    IQR = Q3 - Q1
    lower_range = Q1 - (1.5 * IQR)
    upper_range = Q3 + (1.5 * IQR)

    return lower_range,upper_range


# ### Salary

# In[36]:


continuous_non_viz_analysis(df['Salary'])


# In[37]:


continuous_viz_analysis(df['Salary'])


# ### Salary / Gender

# In[38]:


sns.boxenplot(data=df, x="Gender", y="Salary")


# ##### Male employees are earning more compared to Women

# ### Salary / Experience

# In[39]:


sns.lmplot(x="WorkYear", y="Salary", data=df)


# ### Experience / Age

# In[40]:


sns.lmplot(x="Age", y="WorkYear", data=df)


# ### 10 board and 12 board

# In[41]:


from scipy.stats import chi2_contingency

contingency_table = pd.crosstab(df['10board'], df['12board'])
chi2, p, _, _ = chi2_contingency(contingency_table)


print(f"Chi-square value: {chi2}")
print(f"P-value: {p}")


alpha = 0.05
print(f"Is the result significant at {alpha} level? {'Yes' if p < alpha else 'No'}")


# In[42]:


df['Gender'].unique()


# In[43]:


amcat_marks['Average'] = (amcat_marks['English'] + amcat_marks['Logical'] + amcat_marks['Quant'])/3


# In[44]:


amcat_marks


# In[45]:


amcat_marks['Average_amcat_percentage'] = (amcat_marks['Average']/900)*100


# In[46]:


amcat_marks['10percentage'] = df['10percentage']
amcat_marks['12percentage'] = df['12percentage']
amcat_marks['collegeGPA'] = df['collegeGPA']


# In[47]:


amcat_marks


# ### Graduation

# In[48]:


continuous_viz_analysis(df['GraduationYear'])


# In[49]:


# Remove outliers for Graduation Year and perform EDA
percentile25 = df['GraduationYear'].quantile(0.25)
percentile75 = df['GraduationYear'].quantile(0.75)


# In[50]:


iqr=percentile75-percentile25


# In[51]:


upper_limit = percentile75 + 1.5 * iqr
lower_limit = percentile25 - 1.5 * iqr


# In[52]:


df = df[df['GraduationYear'] < upper_limit]
df = df[df['GraduationYear'] > lower_limit]


# In[53]:


continuous_viz_analysis(df['GraduationYear'])


# ### GPA & Marks are correlated`

# In[54]:


columns_to_plot = amcat_marks[['10percentage', '12percentage', 'collegeGPA', 'Average_amcat_percentage']]


correlation_matrix = columns_to_plot.corr()


plt.figure(figsize=(8, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', vmin=-1, vmax=1,fmt=".2f")
plt.title("Correlation Heatmap for Three Variables")
plt.show()


# In[55]:


columns_to_plot = amcat_marks[['English', 'Logical', 'Quant']]


correlation_matrix = columns_to_plot.corr()


plt.figure(figsize=(8, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', vmin=-1, vmax=1,fmt=".2f")
plt.title("Correlation Heatmap for Three Variables")
plt.show()


# In[56]:


columns_to_consider = ['ComputerProgramming', 'ElectronicsAndSemicon', 'ComputerScience',
                        'MechanicalEngg', 'ElectricalEngg', 'TelecomEngg', 'CivilEngg']


amcat_marks['domain_amcat'] = amcat_marks[columns_to_consider].apply(lambda row: row.idxmax() if row.max() != -1 else None, axis=1)


# In[57]:


sns.countplot(y='domain_amcat',data=amcat_marks)


# In[58]:


df['Specialization'].unique()


# In[59]:


amcat_marks['domain_amcat'].unique()


# In[60]:


def clean_row_domain(row): 
    if row is None:
        return None
    elif 'ComputerProgramming' in row:
        return 'CSE'
    elif 'ElectronicsAndSemicon' in row:
        return 'ECE'
    elif 'MechanicalEngg' in row:
        return 'Mechanical Engg'
    elif 'ElectricalEngg' in row:
        return 'EEE'
    elif 'ComputerScience' in row:
        return 'CSE'
    elif 'TelecomEngg' in row:
        return 'ECE'
    elif 'CivilEngg' in row:
        return 'Civil Engg'


# In[61]:


amcat_marks['domain_amcat'] = amcat_marks['domain_amcat'].apply(clean_row_domain)


# In[62]:


amcat_marks['domain_amcat']


# In[ ]:





# In[63]:


contingency_table = pd.crosstab(df['Specialization'], amcat_marks['domain_amcat'])
chi2, p, _, _ = chi2_contingency(contingency_table)


print(f"Chi-square value: {chi2}")
print(f"P-value: {p}")


alpha = 0.05
print(f"Is the result significant at {alpha} level? {'Yes' if p < alpha else 'No'}")


# ### Salary / Specialization

# In[64]:


plt.figure(figsize=(8, 6))
sns.boxplot(y='Specialization',x='Salary',data=df)


# ### Students

# In[65]:


df['School_average'] = ((df['10percentage'] + df['12percentage'])/2)


# In[66]:


df['School_average'].describe()


# In[67]:


from scipy.stats import pearsonr

correlation_coefficient, p_value = pearsonr(df['School_average'], df['collegeGPA'])
print(f"Pearson correlation coefficient: {correlation_coefficient}")
print(f"P-value: {p_value}")

# Create a scatter plot for visualization
plt.scatter(df['School_average'], df['collegeGPA'])
plt.xlabel('School Marks')
plt.ylabel('College Marks')
plt.title('Scatter Plot of School Marks vs College Marks')
plt.show()


# ### AMCAT score / salary

# In[68]:


'''
correlation_coefficient, p_value = pearsonr(amcat_marks['Average_amcat_percentage'], df['Salary'])
print(f"Pearson correlation coefficient: {correlation_coefficient}")
print(f"P-value: {p_value}")

x = amcat_marks['Average_amcat_percentage']
y = df['Salary']
# Create a scatter plot for visualization
slope, intercept = np.polyfit(x, y, 1)

# Add the regression line


slope, intercept = np.polyfit(amcat_marks['Average_amcat_percentage'], df['Salary'], 1)
plt.scatter(amcat_scores['Average_amcat_percentage'], df['Salary'])
plt.plot(x, slope * x + intercept, color='red', label='Regression Line')
plt.xlabel('AMCAT Score')
plt.ylabel('Salary')
plt.title('Scatter Plot of AMCAT Score vs Salary')
plt.show()
'''


# In[69]:


columns_to_plot = df[['CollegeTier', 'Salary']]


correlation_matrix = columns_to_plot.corr()


plt.figure(figsize=(8, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', vmin=-1, vmax=1,fmt=".2f")
plt.title("Correlation Heatmap for Three Variables")
plt.show()


# In[70]:


sns.boxenplot(data=df, x="CollegeTier", y="Salary")


# In[71]:


df['JobCity'] = df['JobCity'].apply(lambda x: x.lower() if isinstance(x, str) else x)


# In[72]:


df['JobCity']


# In[73]:


from scipy.stats import chi2_contingency

contingency_table = pd.crosstab(df['JobCity'], df['CollegeState'])
chi2, p, _, _ = chi2_contingency(contingency_table)


print(f"Chi-square value: {chi2}")
print(f"P-value: {p}")


alpha = 0.05
print(f"Is the result significant at {alpha} level? {'Yes' if p < alpha else 'No'}")


# In[74]:


import numpy as np
from scipy.stats import ttest_1samp

# Collect data (replace this with your actual data)
data = np.array([250000, 270000, 280000, 260000, 290000])

# Claimed mean from the statement
claimed_mean = 250000

# Set the significance level
alpha = 0.05

# Perform one-sample t-test
t_stat, p_value = ttest_1samp(data, claimed_mean)

# Compare p-value with significance level
if p_value < alpha:
    print("Reject the null hypothesis. There is enough evidence to suggest that the average salary is greater than the claimed value.")
else:
    print("Fail to reject the null hypothesis. There is not enough evidence to suggest that the average salary is greater than the claimed value.")


# In[75]:


df['Designation'].unique()


# In[76]:


def clean_row_designation(row): 
    if 'software' in row:
        return 'Software Engineer'
    elif 'hardware' in row:
        return 'Hardware Engineer'
    elif 'associate' in row:
        return 'Associate Engineer'
    elif 'program' in row:
        return 'Programming Analyst'


# In[77]:


df['Designation_standardize'] = df['Designation'].apply(clean_row_designation)


# In[78]:


df['Designation_standardize'].unique()


# In[79]:


df.head()


# In[80]:


software = df[df['Designation_standardize'] == 'Software Engineer']
hardware = df[df['Designation_standardize'] == 'Hardware Engineer']
associate = df[df['Designation_standardize'] == 'Associate Engineer']
programming = df[df['Designation_standardize'] == 'Programming Analyst']
ece_salary = df[df['Specialization'] == 'ECE']


# In[81]:


dataset = [software,hardware,associate,programming]
data_label = ['Software Enginnering', 'Hardware Engineer', 'Associate Engineer', 'Programming Analyst']


# In[82]:


from scipy.stats import ttest_1samp

alpha = 0.05
claimed_mean = 250000
for i in dataset:
    t_stat, p_value = ttest_1samp(i['Salary'], claimed_mean)
    print(t_stat)
    print(p_value)
    data_label = ['Software Enginnering', 'Hardware Engineer', 'Associate Engineer', 'Programming Analyst']
    if p_value < alpha:
        print(f"\nReject the null hypothesis. There is enough evidence to suggest that the average salary is greater than the claimed value.")
    else:
        print(f"\nFail to reject the null hypothesis. There is not enough evidence to suggest that the average salary is greater than the claimed value.")


# In[83]:


sns.countplot(data = df, x = 'Degree')


# In[84]:


sns.countplot(data = df, y = 'Specialization')


# In[85]:


sns.boxplot(data = ece_salary, x = 'Salary')


# In[86]:


ece_salary['Salary'].mean()


# In[87]:


ece_salary['Salary'].max()


# In[ ]:




